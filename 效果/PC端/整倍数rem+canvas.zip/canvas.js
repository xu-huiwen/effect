(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 1334,
	height: 352,
	fps: 16,
	color: "#FFFFFF",
	manifest: []
};



// symbols:



(lib.guanyu000 = function() {
	this.spriteSheet = ss["01_atlas_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.guanyu002 = function() {
	this.spriteSheet = ss["01_atlas_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.guanyu004 = function() {
	this.spriteSheet = ss["01_atlas_"];
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.guanyu006 = function() {
	this.spriteSheet = ss["01_atlas_"];
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.guanyu008 = function() {
	this.spriteSheet = ss["01_atlas_"];
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.guanyu010 = function() {
	this.spriteSheet = ss["01_atlas_"];
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.guanyu012 = function() {
	this.spriteSheet = ss["01_atlas_"];
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.guanyu014 = function() {
	this.spriteSheet = ss["01_atlas_"];
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.guanyu016 = function() {
	this.spriteSheet = ss["01_atlas_"];
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.guanyu018 = function() {
	this.spriteSheet = ss["01_atlas_"];
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.guanyu020 = function() {
	this.spriteSheet = ss["01_atlas_"];
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.guanyu022 = function() {
	this.spriteSheet = ss["01_atlas_"];
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.guanyu024 = function() {
	this.spriteSheet = ss["01_atlas_"];
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.guanyu026 = function() {
	this.spriteSheet = ss["01_atlas_"];
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.guanyu028 = function() {
	this.spriteSheet = ss["01_atlas_"];
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.guanyu030 = function() {
	this.spriteSheet = ss["01_atlas_"];
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.guanyu = function() {
	this.spriteSheet = ss["01_atlas_"];
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.元件1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.guanyu000();
	this.instance.setTransform(0,122.5);

	this.instance_1 = new lib.guanyu002();
	this.instance_1.setTransform(0,122.5);

	this.instance_2 = new lib.guanyu004();
	this.instance_2.setTransform(0,122.5);

	this.instance_3 = new lib.guanyu006();
	this.instance_3.setTransform(0,122.5);

	this.instance_4 = new lib.guanyu008();
	this.instance_4.setTransform(0,122.5);

	this.instance_5 = new lib.guanyu010();
	this.instance_5.setTransform(0,122.5);

	this.instance_6 = new lib.guanyu012();
	this.instance_6.setTransform(0,122.5);

	this.instance_7 = new lib.guanyu014();
	this.instance_7.setTransform(0,122.5);

	this.instance_8 = new lib.guanyu016();
	this.instance_8.setTransform(0,122.5);

	this.instance_9 = new lib.guanyu018();
	this.instance_9.setTransform(0,122.5);

	this.instance_10 = new lib.guanyu020();
	this.instance_10.setTransform(0,122.5);

	this.instance_11 = new lib.guanyu022();
	this.instance_11.setTransform(0,122.5);

	this.instance_12 = new lib.guanyu024();
	this.instance_12.setTransform(0,122.5);

	this.instance_13 = new lib.guanyu026();
	this.instance_13.setTransform(0,122.5);

	this.instance_14 = new lib.guanyu028();
	this.instance_14.setTransform(0,122.5);

	this.instance_15 = new lib.guanyu030();
	this.instance_15.setTransform(0,122.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_3}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_7}]},2).to({state:[{t:this.instance_8}]},2).to({state:[{t:this.instance_9}]},2).to({state:[{t:this.instance_10}]},2).to({state:[{t:this.instance_11}]},2).to({state:[{t:this.instance_12}]},2).to({state:[{t:this.instance_13}]},2).to({state:[{t:this.instance_14}]},2).to({state:[{t:this.instance_15}]},2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,122.5,411,212);


// stage content:
(lib._01 = function() {
	this.initialize();

	// 图层 2
	this.instance = new lib.元件1();
	this.instance.setTransform(197,-22.4,1,1,0,0,0,-6.5,100);
	this.instance.compositeOperation = "lighter";

	// 图层 1
	this.instance_1 = new lib.guanyu();

	this.addChild(this.instance_1,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(667,176,1334,352);

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;