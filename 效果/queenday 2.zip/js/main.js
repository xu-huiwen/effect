//开始
$(".btn_start").click(function(){
	$(".start_box").css("display","none")
	$(".qa_box").css("display","block")
	$(".top_tit").css("display","block")
	$(".top_tit").text("女王节人格大测试")
	$(".qa_con").eq(0).css("display","block")
})
//随机数
var be=99.1,
    en=99.9;
function myFunction(begin,end){
    var num = Math.random()*(end-begin)+begin;
    num = Math.round(num*10)/10
    return num;
}
//选中
var qanum=0,
	truenum=0;
$(".J_choice a").click(function(){
	var that=$(this)
	that.siblings().addClass("gary")
	if(that.hasClass("y")){
		that.addClass("true")
	}else{
		that.addClass("false")
	}
	setTimeout(function(){
		that.parent().css("display","none")
		that.parent().siblings(".true_box").css("display","block")
		that.parents(".qa_con").find(".qa_pic").find("img").css("display","none")
		that.parents(".qa_con").find(".qa_pic").find("img").eq(1).css("display","block")
	},500)
})
//下一题
$(".J_next").click(function(){
	var that=$(this)
	if(qanum==3){
		truenum=$(".true").length;
		that.parents(".qa_con").css("display","none")
		$(".qa_box").css("display","none")
		$(".result_box").css("display","block")
		$(".top_tit").text("厉害了，TA竟然是这种女王")
		$(".true_num").text(truenum)
		$(".result_txt").eq(truenum).siblings(".result_txt").css("display","none")
		$(".result_txt").eq(truenum).css("display","block")
		$(".result_pic img").eq(truenum).siblings("img").css("display","none")
		$(".result_pic img").eq(truenum).css("display","block")
		if(truenum==0){
			$(".result_tit1").css("display","none")
			$(".result_tit2").css("display","block")
			$(".result_name").text("任性千金")
		}
		if(truenum==1){
			be=60.1;
			en=69.9;
			$(".result_name").text("任性千金")
		}
		if(truenum==2){
			be=70.1;
			en=79.9;
			$(".result_name").text("大生活家")
		}
		if(truenum==3){
			be=80.1;
			en=89.9;
			$(".result_name").text("趣潮玩咖")
		}
		if(truenum==4){
			be=90.1;
			en=99.9;
			$(".result_name").text("颜值能打")
		}
		$(".win_num").text(myFunction(be,en))
	}else{
		qanum++;
		that.parents(".qa_con").css("display","none")
		$(".qa_con").eq(qanum).css("display","block")
	}
})
//再来一遍
$(".J_again").click(function(){
	qanum=truenum=0;
	$(".J_choice a").removeClass("true")
	$(".J_choice a").removeClass("false")
	$(".J_choice a").removeClass("gary")
	$(".result_box,.true_box").css("display","none")
	$(".qa_box,.J_choice").css("display","block")
	$(".qa_con").eq(0).css("display","block")
	$(".result_tit1").css("display","block")
	$(".result_tit2").css("display","none")
	$(".top_tit").text("女王节人格大测试")
	$(".qa_pic img:nth-of-type(2)").css("display","none")
	$(".qa_pic img:nth-of-type(1)").css("display","block")
})
//截屏分享
$(".J_fx").click(function(){
	$(".end_btn").css("display","none")
	$(".code_box").css("display","block")
	setTimeout(screenshot,300)
})

function share(url){
  var shareParam = {
      shareData:[{
          name: "Weixin",
          param:{
	          type: "image",
            imageURL: url
          }
      },{
          name: "WeixinMoments",
          param: {
            type: "image",
            imageURL: url
          }
        }]
  };
  lib.windvane.call('CNHybridGGShareBoard', 'share', shareParam, (o) => {});
}
function screenshot(){
	var params = {
//    textContent: "长按二维码下载裹裹，看看你是哪种女王",  //截图左下方要添加的文案
//    imageUrl: "https://gw.alicdn.com/tfs/TB1gabjJgTqK1RjSZPhXXXfOFXa-180-180.png", //截图右下方要添加的图片的url
    isUseDiskUrl: false
  };
  window.WindVane.call('CNHybridCaptureView', 'captureView', params, (res) => {
	    var url = res.data.captureViewUrl;
			share(url);

			setTimeout(function() {
        $(".end_btn").css("display","block")
        $(".code_box").css("display","none")
			}, 1000)
	 });
}