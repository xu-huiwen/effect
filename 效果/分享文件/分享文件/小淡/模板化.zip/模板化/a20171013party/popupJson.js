var tabFocusImg = "http://game.gtimg.cn/images/rf/cp/a20170515pvp/focus.jpg" 
var popupJson = [{
            "tab_name" : "1",
            "list" : [{
            "item_desc" :"活动期间内，1月25日后，未登陆过游戏的逆战士兵，可领取回归专属NZ币。",
            "item_img" :"http://game.gtimg.cn/images/codo/2017/atemple/img/get1.jpg",
            "item_img_desc" : "朱雀，圣光裁决，死神猎手，幽冥毒皇，黄金",
            "item_btn":"立即领取"
            }]
            },{
            "tab_name" : "1",
            "list" : [{
            "item_desc" :"活动期间内，1月25日后，未登陆过游戏的逆战士兵，可领取回归专属NZ币。",
            "item_img" :"http://game.gtimg.cn/images/codo/2017/atemple/img/get1.jpg",
            "item_img_desc" : "朱雀，圣光裁决，死神猎手，幽冥毒皇，黄金",
            "item_btn":"立即领取"
            }]
            },{
            "tab_name" : "3",
            "list" : [{
            "item_name" :"史诗武器相赠",
            "item_desc" :"活动期间内，1月25日后，未登陆过游戏的逆战士兵，可领取回归专属NZ币。",
            "item_img" :"http://game.gtimg.cn/images/codo/2017/atemple/img/col3.jpg",
            "item_img_desc" : "朱雀，圣光裁决，死神猎手，幽冥毒皇，黄金",
            "item_btn":"立即领取",
            "item_way_desc":"领取方式一描述"
            },{
            "item_name" :"史诗武器相赠",
            "item_desc" :"活动期间内，1月25日后，未登陆过游戏的逆战士兵，可领取回归专属NZ币。",
            "item_img" :"http://game.gtimg.cn/images/codo/2017/atemple/img/col3.jpg",
            "item_img_desc" : "朱雀，圣光裁决，死神猎手，幽冥毒皇，黄金",
            "item_btn":"立即领取",
            "item_way_desc":"领取方式一描述"
            },{
            "item_name" :"史诗武器相赠",
            "item_desc" :"活动期间内，1月25日后，未登陆过游戏的逆战士兵，可领取回归专属NZ币。",
            "item_img" :"http://game.gtimg.cn/images/codo/2017/atemple/img/col3.jpg",
            "item_img_desc" : "朱雀，圣光裁决，死神猎手，幽冥毒皇，黄金",
            "item_btn":"立即领取",
            "item_way_desc":"领取方式一描述"
            }]
            },{
                "tab_name" :  "抽奖12",
                "lottery_status" :  "每日完成任务可以获得相应的抽奖资格。活动期间",
                "lottery_img" : "http://game.gtimg.cn/images/codo/2017/atemple/img/12.jpg",
                "lottery_num" : "您还剩<b id='lotteryNum12'>5个</b>抽奖资格"
            },{
            "tab_name" :  "兑换10",
            "tab_desc" :  "每日完成任务可以获得相应的抽奖资格，活动期间，玩家完成每项任务，即可······",
            "tab_num"  :  4,
            "list" : [{
                "item_name" :"武器名称",
                "item_desc" :"限量",
                "item_img" :"http://game.gtimg.cn/images/codo/2017/atemple/img/exchange_guy_10.jpg",
                "item_btn":"兑换",
                "item_num_sum":"5个",
                "item_num_leave":"还剩<b>4</b>个"
                },{
                "item_name" :"武器名称",
                "item_desc" :"限量",
                "item_img" :"http://game.gtimg.cn/images/codo/2017/atemple/img/exchange_guy_10.jpg",
                "item_btn":"兑换",
                "item_num_sum":"5个",
                "item_num_leave":"还剩<b>4</b>个"
                },{
                "item_name" :"武器名称",
                "item_desc" :"限量",
                "item_img" :"http://game.gtimg.cn/images/codo/2017/atemple/img/exchange_guy_10.jpg",
                "item_btn":"兑换",
                "item_num_sum":"5个",
                "item_num_leave":"还剩<b>4</b>个"
                },{
                "item_name" :"武器名称",
                "item_desc" :"限量",
                "item_img" :"http://game.gtimg.cn/images/codo/2017/atemple/img/exchange_guy_10.jpg",
                "item_btn":"兑换",
                "item_num_sum":"5个",
                "item_num_leave":"还剩<b>4</b>个"
                },{
                "item_name" :"武器名称",
                "item_desc" :"限量",
                "item_img" :"http://game.gtimg.cn/images/codo/2017/atemple/img/exchange_guy_10.jpg",
                "item_btn":"兑换",
                "item_num_sum":"5个",
                "item_num_leave":"还剩<b>4</b>个"
                },{
                "item_name" :"武器名称",
                "item_desc" :"限量",
                "item_img" :"http://game.gtimg.cn/images/codo/2017/atemple/img/exchange_guy_10.jpg",
                "item_btn":"兑换",
                "item_num_sum":"5个",
                "item_num_leave":"还剩<b>4</b>个"
                },{
                "item_name" :"武器名称",
                "item_desc" :"限量",
                "item_img" :"http://game.gtimg.cn/images/codo/2017/atemple/img/exchange_guy_10.jpg",
                "item_btn":"兑换",
                "item_num_sum":"5个",
                "item_num_leave":"还剩<b>4</b>个"
                },{
                "item_name" :"武器名称",
                "item_desc" :"限量",
                "item_img" :"http://game.gtimg.cn/images/codo/2017/atemple/img/exchange_guy_10.jpg",
                "item_btn":"兑换",
                "item_num_sum":"5个",
                "item_num_leave":"还剩<b>4</b>个"
                },{
                "item_name" :"武器名称",
                "item_desc" :"限量",
                "item_img" :"http://game.gtimg.cn/images/codo/2017/atemple/img/exchange_guy_10.jpg",
                "item_btn":"兑换",
                "item_num_sum":"5个",
                "item_num_leave":"还剩<b>4</b>个"
                },{
                "item_name" :"武器名称",
                "item_desc" :"限量",
                "item_img" :"http://game.gtimg.cn/images/codo/2017/atemple/img/exchange_guy_10.jpg",
                "item_btn":"兑换",
                "item_num_sum":"5个",
                "item_num_leave":"还剩<b>4</b>个"
                }]
            }]