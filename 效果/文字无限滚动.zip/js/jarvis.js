// JavaScript Document
function textScroll(pDiv, cli, times){
	var ul2 = $('.'+pDiv)[0].outerHTML;
	var ul1 = $('.'+pDiv).eq(0);
	var lih = ul1.find(cli).height();
	var ulHeight = ul1.find(cli).length * lih;
	var t1 = 0, t2 = ulHeight, tObj = [false, false];
	$('.'+pDiv).after(ul2);
	ul2 = $('.'+pDiv).eq(1);
	ul2.css('top',ulHeight+'px');
	function move(){
		t1 -= lih;
		t2 -= lih;
		if(t1 > 0 && !tObj[0]){
			tObj[0] = true;
			ul1.css('display','block');
		}
		if(t2 > 0 && !tObj[1]){
			tObj[1] = true;
			ul2.css('display','block');
		}
		ul1.animate({top: t1 + 'px'}, 'slow', function(){
			if(-t1 == ulHeight){
				t1 = t2 + ulHeight;
				tObj[0] = false;
				ul1.css({
					'top':t1 + 'px',
					'display':'none'
				});
			}
		});
		ul2.animate({top: t2 + 'px'}, 'slow', function(){
			if(-t2 == ulHeight){
				t2 = t1 + ulHeight;
				tObj[1] = false;
				ul2.css({
					'top':t2 + 'px',
					'display':'none'
				});
			}
		});	
	}
	setInterval(move,times);
}
//参数1 父元素类名
//参数2 子元素标签
//参数3 滚动时间间隔