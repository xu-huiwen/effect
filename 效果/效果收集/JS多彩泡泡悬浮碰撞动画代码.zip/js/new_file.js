/*
鐢熸垚寮规€у皬鐞冪鎾炲伐鍏�
I am kmh0228
QQ:1150123276
2017-06-20
*/
/*
浣跨敤鏂规硶璇存槑
	1.姝ゆ彃浠剁函鍘熺敓js缂栧啓锛屼娇鐢ㄦ椂寮曞叆姝ollision.js鍗冲彲銆�
	2.鐢熸垚瀹瑰櫒锛屽亣璁剧幇鏈変竴涓猧d涓篶ontainer鐨勭洅瀛愬仛瀹瑰櫒銆�
		var oB=new BallBox(鈥榗ontainer鈥�);
			娉細瀹瑰櫒蹇呴』鏄湁瀹介珮鐨勫畾浣嶅厓绱犮€傚敖閲忎笉瑕佹湁杈圭嚎銆�
	3.鐢熸垚灏忕悆
		var ball=new Ball();
	4.鎶婂皬鐞冩斁鍏ュ鍣�
		oB.addBall(ball);
	5.璋冪敤瀹瑰櫒鐨刡allRun鏂规硶锛岃灏忕悆寮€濮嬭繍鍔ㄣ€傛敞鎰忥細姝よ繍鍔ㄦ槸瀹屽叏寮规€х鎾烇紝涓嶄細鎹熷け鑳介噺銆�
		oB.ballRun();
	over
	
	鍙傛暟璇存槑
		瀹瑰櫒鍙傛暟  new BallBox(鈥榗ontainer鈥欙紝opts);
			opts:{width:num,height:num}//娌℃湁杈圭嚎鍜宲adding鐨勬椂鍊欏彲涓嶅啓銆傛湁鐨勬儏鍐典笅闇€瑕佹妸瀹瑰櫒鐪熷疄瀹介珮濉繘鍘汇€�
		灏忕悆鍙傛暟 new Ball(opts);
			opts:{
				e:灏忕悆DOM鍏冪礌/鍘熺敓瀵硅薄锛屽彲濉叆椤甸潰DOM锛屼笉鍐欏垯鐢熸垚鏂癉IV DOM,
				b:灏忕悆鍗婂緞 榛樿30;鍖呭惈杈�
				c:灏忕悆鑳屾櫙棰滆壊/鍥剧墖锛� 榛樿'pink'
				borderWidth:杈圭嚎瀹藉害 榛樿0
				borderColor:杈圭嚎棰滆壊 榛樿#000
				x:灏忕悆涓績鐐圭殑妯潗鏍� 榛樿涓哄崐寰�
				y:灏忕悆涓績鐐圭殑绾靛潗鏍� 榛樿涓哄崐寰�
				sx:灏忕悆鍦▁杞存柟鍚戦€熷害姣�30ms锛岄粯璁�3
				sy:灏忕悆鍦▂杞存柟鍚戦€熷害姣�30ms锛岄粯璁�3
				m:灏忕悆鐨勮川閲忥紝榛樿b/30;
				html:灏忕悆鍐呴儴鐨勫唴瀹癸紝涓嶅～鍒欎笉浼氭敼鍙楧OM鏈韩鐨勫唴瀹广€�
				fontSize:瀛椾綋澶у皬锛岄粯璁�12;
				opa:灏忕悆閫忔槑搴︼紝榛樿1锛�
				callBack:function  纰版挒鏃剁殑鍥炴帀鍑芥暟锛屽弬鏁颁负纰版挒鐨勬€绘鏁帮紝鏂规硶涓璽his鎸囧悜姝ょ悆瀵硅薄
			}
		灏忕悆鏂规硶锛�
				setB(num)//閲嶆柊璁剧疆灏忕悆鍗婂緞
				setC(str);//閲嶆柊璁剧疆灏忕悆鑳屾櫙棰滆壊/鍥剧墖
				setBorderWidth(n);//閲嶆柊璁剧疆灏忕悆杈圭嚎瀹藉害
				setBorderColor(str);//閲嶆柊璁剧疆杈圭嚎棰滆壊
				setM(n);//閲嶈灏忕悆璐ㄩ噺,濡傛灉涓嶇粰鍙傛暟锛屽垯鎸夌収鍗婂緞閲嶆柊榛樿璐ㄩ噺
				setHTML(str);//閲嶈灏忕悆鍐呭
				setOpa(n);//閲嶈灏忕悆閫忔槑搴�

 
 */


function BallBox(a, b) {
	var c = this.container = document.getElementById(a);
	var b = this.opts = b || {};
	this.width = b.width || c.offsetWidth;
	this.height = b.height || c.offsetHeight;
	this.child = []
}
BallBox.prototype.addBall = function(a) {
	this.child.push(a);
	if (a.e.parentNode != this.container) {
		this.container.appendChild(a.e)
	}
};
BallBox.prototype.ballRun = function() {
	clearInterval(this.ballRunTimer);
	var g = this;
	var w = this.width;
	var h = this.height;
	var k = this.isColl;
	var l = this.coll;
	this.ballRunTimer = setInterval(function() {
		var a = g.child;
		var c = a.length;
		for (var i = 0; i < c; i++) {
			a[i].foot()
		}
		for (var i = 0; i < c; i++) {
			var d = a[i];
			var b = d.b;
			if (d.x < b) {
				d.x = b;
				d.sx *= -1
			}
			if (d.y < b) {
				d.y = b;
				d.sy *= -1
			}
			var e = w - b;
			if (d.x > e) {
				d.x = e;
				d.sx *= -1
			}
			var f = h - b;
			if (d.y > f) {
				d.y = f;
				d.sy *= -1
			}
		}
		for (var i = 0; i < c; i++) {
			for (var j = i + 1; j < c; j++) {
				if (k(a[i], a[j])) {
					l(a[i], a[j]);
					a[i].collNum++;
					a[i].callBack(a[i].collNum);
					a[j].collNum++;
					a[j].callBack(a[j].collNum)
				}
			}
		}
	}, 30)
};
BallBox.prototype.ballStop = function() {
	clearInterval(this.ballRunTimer)
};
BallBox.prototype.coll = function(a, b) {
	var c = b.x - a.x;
	var d = b.y - a.y;
	var e = b.sx - a.sx;
	var f = b.sy - a.sy;
	var g = Math.atan2(f, e);
	var h = Math.atan2(-d, -c);
	var i = Math.abs(h - g);
	var D = Math.PI / 2;
	if (i <= 3 * D && i >= D) return;
	var j = a.m || 1;
	var k = b.m || 1;
	var l = j + k;
	var m = ((j - k) * a.sx + 2 * k * b.sx) / l;
	var n = ((k - j) * b.sx + 2 * j * a.sx) / l;
	var o = ((j - k) * a.sy + 2 * k * b.sy) / l;
	var p = ((k - j) * b.sy + 2 * j * a.sy) / l;
	a.sx = m;
	a.sy = o;
	b.sx = n;
	b.sy = p
};
BallBox.prototype.isColl = function(a, b) {
	if (a.stopfoot || b.stopfoot) return false;
	var d = Math.pow(a.x - b.x, 2) + Math.pow(a.y - b.y, 2);
	var c = Math.pow(a.b + b.b, 2);
	return d < c
};

function Ball(a) {
	var a = this.json = a || {};
	var d = this.type = a.type || 'ball';
	var b = this.b = a.b || 30;
	var f = this.borderWidth = a.borderWidth || 0;
	var g = this.borderColor = a.borderColor || '#000';
	var x = this.x = a.x || b;
	var y = this.y = a.y || b;
	var h = this.sx = a.sx || 3;
	var i = this.sy = a.sy || 3;
	var m = this.m = a.m || (b / 30);
	var c = this.c = a.c || 'pink';
	var e = this.e = a.e || document.createElement('div');
	var j = this.html = a.html;
	var k = this.opa = a.opa || 1;
	var l = this.fontSize = a.fontSize || 12;
	var n = this.callBack = a.callBack ||
	function() {};
	this.collNum = 0;
	this.initStyle();
	this.addEvent()
}
Ball.prototype.initStyle = function() {
	var b = this.b;
	var s = this.e.style;
	s.position = 'absolute';
	s.top = s.left = 0;
	s.width = s.height = (b - this.borderWidth) * 2 + 'px';
	s.borderRadius = '50%';
	s.background = this.c;
	s.backgroundSize = 'cover';
	s.border = this.borderWidth + 'px solid ' + this.borderColor;
	s.opacity = this.opa;
	if (this.html) {
		this.e.innerHTML = this.html;
		s.textAlign = 'center';
		s.lineHeight = (b - this.borderWidth) * 2 + 'px';
		s.fontSize = this.fontSize + 'px'
	}
	this.setPos()
};
Ball.prototype.addEvent = function() {
	var a = this;
	this.e.onmouseenter = function() {
		a.stopFoot()
	};
	this.e.onmouseout = function() {
		a.startFoot()
	}
};
Ball.prototype.foot = function(n) {
	if (this.stopfoot) return;
	var n = n || 1;
	this.x += this.sx * n;
	this.y += this.sy * n;
	this.setPos()
};
Ball.prototype.startFoot = function() {
	this.stopfoot = false;
	this.e.style.zIndex = 1
};
Ball.prototype.stopFoot = function() {
	this.stopfoot = true;
	this.e.style.zIndex = 999
};
Ball.prototype.setPos = function() {
	var b = this.b;
	var x = parseInt(this.x - b);
	var y = parseInt(this.y - b);
	this.e.style.transform = 'translate(' + x + 'px,' + y + 'px)';
	this.e.style.webkitTransform = 'translate(' + x + 'px,' + y + 'px)'
};
Ball.prototype.setB = function(n) {
	var b = this.b = n;
	var s = this.e.style;
	s.width = s.height = (b - this.borderWidth) * 2 + 'px';
	s.lineHeight = (b - this.borderWidth) * 2 + 'px';
	this.setPos()
};
Ball.prototype.setC = function(a) {
	var c = this.c = a;
	this.e.style.background = c;
	this.e.style.backgroundSize = 'cover'
};
Ball.prototype.setBorderWidth = function(n) {
	var n = this.borderWidth = n;
	var s = this.e.style;
	s.width = s.height = (this.b - n) * 2 + 'px';
	s.lineHeight = (this.b - n) * 2 + 'px';
	s.border = n + 'px solid ' + this.borderColor
};
Ball.prototype.setBorderColor = function(a) {
	var a = this.borderColor = a;
	this.e.style.border = this.borderWidth + 'px solid ' + a
};
Ball.prototype.setM = function(n) {
	this.m = n || this.b / 30
};
Ball.prototype.setHTML = function(a) {
	var b = this.html = a;
	var s = this.e.style;
	this.e.innerHTML = b;
	s.textAlign = 'center';
	s.lineHeight = (this.b - this.borderWidth) * 2 + 'px';
	s.fontSize = this.fontSize + 'px'
};
Ball.prototype.setOpa = function(n) {
	var a = this.opa = n;
	this.e.style.opacity = n
};