//Բ������
function CreatCircle(e){
	var _this = this;
	this.timer = null;
	this.percent = 0; 
	this.steep = (typeof e.steep !=='number') ? 100 : e.steep;
	this.num = e.num;
	this.box = document.getElementById(e.id);
	this.circle = this.box.getElementsByTagName('circle')[1];
	var w = _this.box.parentNode.offsetWidth;;
	this.perimeter = Math.PI * 2 * w * 0.45;
	this.action();
	this.calloback = e.calloback;
};
CreatCircle.prototype = {
	setDasharray:function (){
		var _this = this;
		if(_this.num>_this.percent){
			_this.percent += 0.1, 
			_this.circle.setAttribute('stroke-dasharray', _this.perimeter * _this.percent + " " + _this.perimeter * (1- _this.percent));
		}else{
			clearInterval(_this.timer);
			  _this.calloback && _this.calloback()
			return false;
		}
	},
	action:function(){
		var _this = this;
		this.timer=setInterval(function(){
			_this.setDasharray()
		},_this.steep)
	}
};	